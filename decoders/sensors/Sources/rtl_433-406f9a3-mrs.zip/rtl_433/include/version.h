#define GIT_VERSION "25.12 (2025-12-12)"
/* #undef GIT_BRANCH */
/* #undef GIT_TIMESTAMP */
